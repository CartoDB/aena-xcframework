//
//  IndoorErrors.swift
//  IndoorSDK
//
//  Created by Joaquin Perez on 28/10/2019.
//  Copyright © 2019 Joaquin Perez. All rights reserved.
//

import Foundation


/// Errors when you try to open a Poi, and it's not success.
@objc public enum OpenPoiError:Int, Error
{
    /// The Poi doesn't exist in the airport. The idPoi should be wrong.
    case PoiDontExist
    
    
    /// The poi can't be reach, usually is a network problem.
    case PoiCantBeReach
}



/// Errors creating a Flight, from a dict.
///
/// There is not a required key (or the data in this key is no valid).
///
///
///  Use: `localizedDescription` to know the missing key.
///
@objc public enum CreateFlightError:Int, Error
{
    case numberFlight
    case companyCode
    case state
    case icaoAirportOrigin
    case airportOrigin
    case nameAirportOrigin
    case icaoAirportDestiny
    case airportDestiny
    case nameAirportDestiny
    
    public var localizedDescription: String
    {
        var key = ""
        switch self {
        case .numberFlight:
            key = "numVuelo"
        case .companyCode:
            key = "codCia"
        case .state:
            key = "estado"
        case .icaoAirportOrigin:
            key = "aeropuertoOrigenOACI"
        case .airportOrigin:
            key = "aeropuertoOrigen"
        case .nameAirportOrigin:
            key = "aeropuertoOrigenNombre"
        case .icaoAirportDestiny:
            key = "aeropuertoDestinoOACI"
        case .airportDestiny:
            key = "aeropuertoDestino"
        case .nameAirportDestiny:
            key = "aeropuertoDestinoNombre"
        }
        return NSLocalizedString("Key missing: ", tableName: nil, bundle: Constants.SDK_BUNDLE, value: "Key missing: ", comment: "Error loc description") + key
    }
}


@objc public enum OpenCategoryListError:Int, Error
{
    
    case AirportIsNotReady
    
    case CategoryDoNotExist
    
    
    public var localizedDescription: String
    {
        switch self {
        case .AirportIsNotReady:
            return NSLocalizedString("Airport is not ready", tableName: nil, bundle: Constants.SDK_BUNDLE, value: "Airport is not ready", comment: "Error localizedString")
          
        case .CategoryDoNotExist:
            return NSLocalizedString("Category don't exist", tableName: nil, bundle: Constants.SDK_BUNDLE, value: "Category don't exist", comment: "Error localizedString")
        }
    }
    
}

