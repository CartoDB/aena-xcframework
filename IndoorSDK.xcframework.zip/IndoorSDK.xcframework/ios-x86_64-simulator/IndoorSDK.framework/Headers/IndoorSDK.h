//
//  IndoorSDK.h
//  IndoorSDK
//
//  Created by Joaquin Perez on 25/10/2019.
//  Copyright © 2019 Joaquin Perez. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "_IndoorAnalytics.h"

#ifdef IndoorSDK_Swift_h
#import "IndoorSDK-Swift.h"
#endif


//! Project version number for UIKitExtensions.
//FOUNDATION_EXPORT double UIKitExtensionsVersionNumber;

//! Project version string for UIKitExtensions.
//FOUNDATION_EXPORT const unsigned char UIKitExtensionsVersionString[];


/// Longitude key. Double. The latitude of the position.
NSString *const IndoorSDKPositionKeyLongitude = @"IndoorSDKPositionKeyLongitude";

/// Latitude key. Double. The longitude of the position.
NSString *const IndoorSDKPositionKeyLatitude = @"IndoorSDKPositionKeyLatitude";

/// Accuracy key. Double. Accuracy position in horizontal.
NSString *const IndoorSDKPositionKeyAccuracy = @"IndoorSDKPositionKeyAccuracy";

/// Building identifier key. String. -1 means outdoor (no building).
NSString *const IndoorSDKPositionKeyBuildingId = @"IndoorSDKPositionKeyBuildingId";

/// Floor identifier key. String. -1 means outdoor, ground floor.
NSString *const IndoorSDKPositionKeyFloorId = @"IndoorSDKPositionKeyFloorId";
 
/// Bearing key. Float. Optional (It could not be).
NSString *const IndoorSDKPositionKeyBearing = @"IndoorSDKPositionKeyBearing";

/// Is indoor key. Bool. true = indoor / false = outdoor.
NSString *const IndoorSDKPositionKeyIsIndoor = @"IndoorSDKPositionKeyIsIndoor";
