//
//  ObjC_catcher.h
//  IndoorSDK
//
//  Created by Joaquin Perez on 24/10/2019.
//  Copyright © 2019 Joaquin Perez. All rights reserved.
//

#import <Foundation/Foundation.h>


NS_ASSUME_NONNULL_BEGIN

@interface _IndoorAnalytics : NSObject

+ (BOOL)catchException:(void(^)(void))tryBlock error:(__autoreleasing NSError **)error;
+ (void)sendAnalytics:(NSString *)name parameters:(NSDictionary *)parameters;
+ (void)sendScreenAnalytics:(NSDictionary *)parameters;

@end



NS_ASSUME_NONNULL_END
