//
//  AenaIndoorMapViewController.swift
//  AenaIndoorSDK
//
//  Created by Joaquin Perez on 03/09/2019.
//  Copyright © 2019 Joaquin Perez. All rights reserved.
//

import UIKit



/// This class is the visual enter point to IndoorSDK
///
/// You usually create and object, load and airport
/// and push inside a navigationController.
///
///````
///    let vC = IndoorMapViewController()
///    vC.loadAirport(icao: "LEMD")
///    navigationController?.pushViewController(vC, animated: true)
/// ````
///
/// ## Important ##
/// All IndoorMapViewController objects must be inside
/// a UINavigationController.
///
///
final public class IndoorMapViewController: UIViewController, DownloadObserver, VectorObjectClickDelegate, CanShowMap {

    
    private override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        _configureInit()
    }
    
    internal required init?(coder: NSCoder) {
        super.init(coder: coder)
        _configureInit()
    }
    
    
    #if DEBUG_IN
    var drawGrafo: DrawGrafo?
    var drawBeacons: DrawSitumBeacons?
    #endif
   
    let mapViewContainer = UIView()
    let visibleMapContainer = UIView()
    var selectorOptionalAction: (()->Void)?
   
    let backButton = UIButton()
    let searchButton = UIButton()


    var bottonBoxOpenLayout: NSLayoutConstraint!
    var bottonBoxCloseLayout: NSLayoutConstraint!
   
    var infoNotReachable = false
   
    var multiPoiVC: MultiPoiBoxVController?
    var shareVC: ShareLocationVController?
    
    var currentIcao: String?
    var loadAirpotCalled = false

    var mapLoaded = false
    var viewInScreen = false
   
    var mapViewController: MainMapVController?
   
   let vectorClick = VectorObjectClickListener()

   
    var startPoiId: Int64?
    var startSharedLocation: CustomLocation?
    var sharedLocation: CustomLocation?
   
    var fligtView = FlightView()
   var flightViewLayout: NSLayoutConstraint!
    
  var startFromOutdoorRoute: Bool {
        if let transition = OutdoorTransitionManager.currentSaved()
        {
            return transition.checkValid()
        }
        return false
    }
    
    var transition: FlightVControllerTransitioning?
    var starPoint: CGFloat?
    
    /// Load the airport.
    ///
    /// You should call this before add IndoorMapViewController
    /// to a navigationController
    ///
    /// - Parameter icao: Airport icao to open
    ///
    @objc public func loadAirport(icao:String)  {
        
       _loadAirport(icao: icao)
        
    }
    
   
    
    /// Load the airport with the Poi selected.
    ///
    /// This method looks for the Poi in the device cache database. If it finds it, it loads the map with the selected poi and returns true. Otherwise it returns false, and makes the request to catch the info from the servers. After receiving the info from the servers, it excecutes the ready block. If the poi has been found on the servers, the success parametres will be true and the view controller could be pushed, if not, it is false, the error parameter gives the error, and the viewController shouldn’t be pushed.
    ///
    /// - Parameter idPoi: the identifier of the poi to select
    /// - Parameter icao: Icao code of the airport where te Poi is.
    /// - Parameter readyBlock: closure called after requesting the poi to server.
    /// - Parameter success: If the request return the poi.
    /// - Parameter err: Error if success is false.
    ///
    /// Example of implementation:
    /// ````
    ///         let vC = IndoorMapViewController()
    /// if vC.loadPoi(idPoi: idPoi, inAirport: airportIcao, readyBlock: { (success, err) in
    ///    if success {
    ///        // Remove the activity indicator.
    ///        self.navigationController?.pushViewController(vC, animated: true)
    ///    } else {
    ///        print(err)
    ///        // Catch info from error and managed.
    ///    }
    ///
    ///}) {
    /// navigationController?.pushViewController(vC, animated: true)
    ///} else {
    ///    // Present and activity indicator.
    ///}
    ///````
    ///
    ///
    /// - Returns: true if the Poi is in the cache. Otherwise return false.
    ///
    @objc public func loadPoi(idPoi: Int64, inAirport icao:String,
                            readyBlock:@escaping (_ success: Bool, _ err:Error?)-> Void) -> Bool
    {
        return _loadPoi(idPoi: idPoi, inAirportIcao: icao, readyBlock: readyBlock)
    }
  
    
    
    /// Open a POI in a loaded Airpot.
    ///
    /// This method only has effect if the IndoorMapViewController is
    /// loaded.
    ///
    ///
    /// - Parameter idPoi: the identifier of the poi to select
    ///
    /// - Throws: `OpenPoiError.PoiDontExist`.
    ///            if `idPoi` doesn't match with
    ///            current Pois in DB.
    ///
    @objc public func openPoi(idPoi:Int64) throws
    {
        do {
         try _openPoi(idPoi: idPoi)
        }
        catch
        {
            throw error
        }
    }
    

    

    
    deinit {
       
        print("Im out, really out VC!")
        
    }
    


}
