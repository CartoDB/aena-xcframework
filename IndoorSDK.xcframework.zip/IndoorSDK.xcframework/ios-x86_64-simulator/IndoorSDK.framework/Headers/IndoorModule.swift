//
//  IndooSDK.swift
//  IndoorSDK
//
//  Created by Joaquin Perez on 04/09/2019.
//  Copyright © 2019 Joaquin Perez. All rights reserved.
//


import Foundation




/// Main model class of IndoorSDK
///
/// It's a singlenton, you must call 'shared'.

@objc public class IndoorModule: NSObject  {
    
    static let FlightUpdateInfoNotification: Notification.Name = Notification.Name.init("flightUpdateInfoNotification")
    
    // Notifications
    public static let SearchSelectPoiNotification = Notification.Name.init("searchSelectPoi")
    
    /// The shared instance of IndoorSDK class.
    @objc public static let shared = IndoorModule()
    
    
    
    /// Define the constanst keys of the position dictionary.
    ///
    public struct PositionKey {
        /// Longitude key. Double. The latitude of the position.
        public static let longitude = "IndoorSDKPositionKeyLongitude"
        /// Latitude key. Double. The longitude of the position.
        public static let latitude = "IndoorSDKPositionKeyLatitude"
        /// Accuracy key. Double. Accuracy position in horizontal.
        public static let accuracy = "IndoorSDKPositionKeyAccuracy"
        /// Building identifier key. String. -1 means outdoor (no building).
        public static let buildingId = "IndoorSDKPositionKeyBuildingId"
        /// Floor identifier key. String.
        public static let floorId = "IndoorSDKPositionKeyFloorId"
        /// Bearing key. Float. Optional (It could not be).
        public static let bearing = "IndoorSDKPositionKeyBearing"
        /// Is indoor key. Bool. true = indoor / false = outdoor.
        public static let isIndoor = "IndoorSDKPositionKeyIsIndoor"
        
    }
         
    /// Don't use. 
    public var _debugOption = 0

    

    #if DEBUG_IN
    var location:LocationIndoor = MultisourceLocation()   // FakeLocation()
    var beaconList:[Old_Beacon]?
    
    open func __clearSitumCache() { _clearSitumCache() }
    #else
    
    let location =  MultisourceLocation()
    #endif

  
    @available(*, deprecated)
    var flightInfo:[String: Any]?
    
    var flight:Flight?
    var serviceLocationStarted = false
    
    
    /// Action to be excecute when the `flight info`
    /// button is pressed.
    ///  ## Important ##
    ///
    /// ´Deprecated´action is never call
    @available(*, deprecated)
    @objc public var action:(()->Void)?
    
    
    /// It start all stuff
    ///
    ///
    /// Call it as soon as posible.
    /// Recomended place: AppDelegate
    ///
    ///```swift
    ///    func application(_ application: UIApplication,
    ///     didFinishLaunchingWithOptions launchOptions:
    ///      [UIApplication.LaunchOptionsKey: Any]?) -> Bool
    ///```
    ///
    /// - Parameter requestLocation: Use to delay the request location authoritation
    ///
    ///  If requestLocation is false, the request location prompt will be launched when enter
    ///  in map.
    @objc public func start(_ requestLocation: Bool = true)  { _start(requestLocation) }
    
   
    
    /// Request all info about airports
    ///
    /// Call it as soon as you know that the user has selected an airport or flight. It is especially recommended to provide the best user experience when there are more than one airports involved.
    ///
    /// You could use this method in order to manage the cache of airports in the device`s DB.
    ///
    ///  ## Every time you call this method with a list of Icaos, two things happen:
    ///
    ///    1.- The SDK try to do all requests needed to catch (or update) all airports in the icao's list.
    ///
    ///    2.- All airports that are in the device's DB that are not in the list will be deleted from the DB.
    ///
    ///   - Warning:    If you call this method with an empty list, all airports in DB will be deleted.
    ///
    ///   - Parameter icaosArray: List of icaos to request
    ///
    @objc public func requestAirportsInfoFromIcaos(_ icaosArray: [String])
    {
        _requestAirportsInfoFromIcaos(icaosArray)
    }
    
    
    /// User last position
    ///
    /// If you have called start(), you should always have a position, but keep in mind that Situm’s framework gives you a position both when the user is inside or outside an airport.
    ///
    ///
    /// ## Important ##
    ///
    /// You must to call start() before this method.
    ///
    /// - returns: Position in a SITPoint (Situm position object)
    ///            or nil if there is not position.
    ///
    ///
    ///  ##Deprecated: use getUserPosition always return nothing (nil)
    ///
    @available(*, deprecated)
    @objc public func getPosition() -> Any?
    {
        return nil
    }
    
    
    /// User last position
    ///
    /// If you have called start(), you should always have a position, but keep in framework gives you a position both when the user is inside or outside an airport.
    ///
    ///
    ///
    /// - Important: You must to call start() before this method.
    ///
    /// - returns: If there is not any user valid position return nil, If there is position return a dictionary with the position info.
    ///
    ///
    ///  ## Swift keys
    ///.
    ///     The Keys of the dictionary are defined inside the ``IndoorModule/PositionKey``
    ///
    ///  ## ObjC keys
    ///  
    ///     The Keys of the dictionary are defined as global constants, "IndoorSDKPositionKey..."
    ///
    ///
    @objc public func getUserPosition() -> [String: Any]?
    {
        return _getUserPosition()
    }
    
    
    
    
    /// Switch On/Off the **PRM** routes
    /// (People Reduced Mobility)
    ///
    ///  False is the default behaviour.
    ///
    /// - Parameter on:true to use PMR routes,
    ///   false to use normal routes.
    ///
    ///   ## Deprecated:
    ///   This method don't have any effect.
    ///
    @available(*, deprecated)
    @objc public func setPMR(_ on:Bool)
    {
        //_setPMR(on)
    }
    
    
    /// Set the info about the flight.
    ///
    /// ## Important ##
    ///
    ///  If it's not set, the button to show the flight info is hidden.
    ///
    /// - Parameter flightDict: the dictionary with all info about flight
    ///
    /// ## Deprecated: ##
    ///
    ///  Use instead of:
    ///  ````
    ///   setFlight(_ infoDict: )
    ///    ````
    ///
    @available(*, deprecated)
    @objc public func setFlightInfo(_ flightDict:[String:Any])
    {
       try? _setFlightInfo(dict: flightDict)
  
    }
    
    
    
    /// Manage the flight ticket in the SDK.
    ///
    ///  - Call with a valid dictionary and create or update the flight ticket.
    ///  - Call with `nil` to delete the ticket.
    ///
    ///
    /// - Parameter dict: the dictinary with all required info flight.
    ///
    /// - Throws: `CreateFlightError`.
    ///            As soon as requiered key is not present in the dictionary,
    ///            you can know the key in the `localizedDescription` property.
    ///
    @objc public func setFlight(_ infoDict:[String:Any]?) throws
    {
        
        do { try _setFlightInfo(dict: infoDict) }
        catch { throw error }
    }
    
    // <doc:SharePosition>
    
    /// To open a  Share Position
    /// Implement this method in: AppDelegate
    ///
    ///````
    ///        func application(_ application: UIApplication, continue userActivity: NSUserActivity, restorationHandler: @escaping ([UIUserActivityRestoring]?) -> Void) -> Bool {
    ///             return IndoorModule.shared.manageUserActivity(userActivity, andPresentIn: navController, after: [MainDemoAppTViewController(style: .plain)])
    
    ///}
    ///````
    /// - Parameters:
    ///   - userActivity: activity share
    ///   - navController: navigation controller of the app
    ///   - viewControllers: collection of viewcontroller tha must be before the map in the pile
    ///   - prepareToPresent: Any other action you need before present
    /// - Returns: success if IndoorSDK manage this activity
    open func manageUserActivity(_ userActivity:NSUserActivity, andPresentIn navController: UINavigationController, after viewControllers: [UIViewController], prepareToPresent:()->()) -> Bool
    {
        
        return _manageUserActivity(userActivity, andPresentIn: navController, after: viewControllers, prepareToPresent:prepareToPresent)
    }
    
    
    
    /// To ask if an airport is ready
    /// - Parameter icao: airport icao
    /// - Returns: true if the airport is in cache. False if it's not.
    @objc public func airportIsCached(_ icao: String) -> Bool
    {
       return _airportIsCached(icao)
    }
    
    
    
    /// It present the list of POIS in the requested category of an airport, inside the provide navigation controller.
    ///
    /// When you select a POI in the list (or detail view) two things can happen. If the action parameter is nil, the pressed POI is open in the map at the same time the view list is poped. If the action parameter is not nil the view list is poped of the navigation controller and the action is fired.
    /// All of these happen if the airport is cached. Other case an error is throw.
    ///
    /// - Parameters:
    ///   - idCat: category id
    ///   - icao: airport icao
    ///   - inNavController: navigation controller
    ///   - action: action to manage the selection or nil to open map
    ///
    /// - Throws: error if airport is not in cache
    @objc public func loadCategory(_ idCat: Int, inAirport icao: String, inNavController: UINavigationController, action:(([String]) -> Void)?) throws
    {
        do { try _presentListOfCat(idCat, inAirport: icao, inNavController: inNavController, action: action) }
        catch { throw error }
    }
    

    
    /// Info about the current version
    public var version: String
    {
        return _version()
    }
    
    /// Info about the current build
    public var build: String
    {
        return _build()
    }
    
    
    
    /// To ask if a new notification is managed by the indoor module
    /// - Parameter response: The notification response to evaluate
    /// - Returns: the anwser
    public func isIndoorResponse(_ response: UNNotificationResponse) -> Bool
    {
        return _isIndoorResponse(response)
    }
    
    
    // <doc:OutdoorNavigation>
    
    /// To response to Outdoor Navigation notification
    /// Implement this method in: AppDelegate
    ///
    ///````
    ///            func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
    
    /// if IndoorModule.shared.manageNotificationResponse(response, andPresentIn: navController, after: [MainDemoAppTViewController(style: .plain)], prepareToPresent: { self.tabBar.selectedIndex = 1 })
    /// {
    ///    // Managed by Indoor module.
    ///    return
    /// }
    ///
    ///       // Other notifications.
    /// }
    ///````
    /// - Parameters:
    ///   - response: notification response
    ///   - navController: navigation controller of the app
    ///   - viewControllers: collection of viewcontroller tha must be before the map in the pile
    ///   - prepareToPresent: Any other action you need before present
    /// - Returns: success if IndoorSDK manage this response
    open func manageNotificationResponse(_ response: UNNotificationResponse, andPresentIn navController: UINavigationController, after viewControllers: [UIViewController], prepareToPresent:()->()) -> Bool
    {
        return _manageNotificationResponse(response, andPresentIn: navController, after: viewControllers, prepareToPresent: prepareToPresent)
    }
    

    // MARK: Geofence
    
    /// News related with a region in airport.
    public struct GeofenceNew {
        
        public init(name: String, message: String, category: UserNotificationKind, icao: String, idPoi: String?)
        {
            self.name = name
            self.message = message
            self.category = category
            self.icao = icao
            self.idPoi = idPoi
        }
        
        /// The title of the news
        public let name: String
        /// The message of the news
        public let message: String
        /// The kind of the news
        public let category: UserNotificationKind
        /// The icao of the airport where the geofence is.
        public let icao: String
        /// The identifier of the POI related to the news, if it exist (optional).
        public let idPoi: String?
        
    }
    
    
    /// In AENA App users could chose receive info inside three different category, operational, commercial and third parties. This element represent these categories in order of the App info to IndoorSDK about user selection.
    public struct UserNotificationKind: OptionSet {
     
        public let rawValue: Int
        public init(rawValue: Int) {
            self.rawValue = rawValue
        }
        
        /// User doesn't want any.
        public static let none: UserNotificationKind = []
        /// Operational is selected
        public static let operational = UserNotificationKind(rawValue: 1 << 0)
        /// Commercial is selected
        public static let commercial = UserNotificationKind(rawValue: 1 << 1)
        /// Third parties is selected
        public static let thirdParties = UserNotificationKind(rawValue: 1 << 2)
        /// All are selected
        public static let all:UserNotificationKind = [.operational, .commercial, .thirdParties]
        
        static func currentValue() -> UserNotificationKind
        {
            if let value = UserDefaults.standard.value(forKey: Constants.USER_DEFAULTS_KEY.userNotificationKindSelected),
               let intValue = value as? Int
            {
                return UserNotificationKind(rawValue: intValue)
            }
            else
            {
                return .all
            }
        }
        static func save(_ value: UserNotificationKind)
        {
            UserDefaults.standard.setValue(value.rawValue, forKey: Constants.USER_DEFAULTS_KEY.userNotificationKindSelected)
            UserDefaults.standard.synchronize()
        }
    }
    
    
    /// Use this to set the user notifications selection.
    /// - Parameter activeNot: User selection
    public func userActiveNotifications(_ activeNot:UserNotificationKind)
    {
        UserNotificationKind.save(activeNot)
        location.geofenceManager?.updateCurrentGeofences()
    }
    
    // <doc:Geofence>
    
    /// Function to manage Geofence functionality
    ///
    ///  This function will be called every time the user enter in a geofence.
    /// - Parameter  GeofenceNew: The news to show to the user
    ///
    /// - Returns: You must return true if the news has been show to the user and false if not.
    public var enterInGeofenceAction: ((GeofenceNew) -> Bool)?
 
    
    private override init() { super.init() }
    
    
    var _forceOutdoorTransitionPoint: (lon:Double, lat: Double)?
    
    public func _forceOutdoorTransitionIn(lon:Double, lat: Double)
    {
        
        if "2022" > Date().description {
        _forceOutdoorTransitionPoint = (lon,lat)
        }
    }
    public func _removeForceOT()
    {
        _forceOutdoorTransitionPoint = nil
    }

}


